﻿//Write a program to prompt the user to enter a single character. The program should display a message like “Your response was y”. For this question, you must use a variable of type char.//
Console.Write("Enter your favourite number from 1-9: ");
char userInputChar;
while (!char.TryParse(Console.ReadLine(), out userInputChar) || userInputChar == '\0')
{
    Console.WriteLine("Invalid input. Please enter a number from 1-9: ");
}
Console.WriteLine($"\nYour favourite number is {userInputChar}\n");
